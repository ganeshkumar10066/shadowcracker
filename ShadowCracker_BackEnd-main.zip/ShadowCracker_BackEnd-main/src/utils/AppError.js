class AppError extends Error {
    constructor(message, statusCode, isCritical = false) {
        super(message);
        this.statusCode = statusCode;
        this.isCritical = isCritical;
        this.status = `${statusCode}`.startsWith('4') ? 'fail' : 'error';
        
        Error.captureStackTrace(this, this.constructor);
    }

    static badRequest(message) {
        return new AppError(message, 400);
    }

    static unauthorized(message = 'Unauthorized access') {
        return new AppError(message, 401);
    }

    static forbidden(message = 'Forbidden access') {
        return new AppError(message, 403);
    }

    static notFound(message = 'Resource not found') {
        return new AppError(message, 404);
    }

    static validationError(message) {
        const error = new AppError(message, 400);
        error.name = 'ValidationError';
        return error;
    }

    static rateLimit(message = 'Rate limit exceeded') {
        const error = new AppError(message, 429);
        error.name = 'RateLimitError';
        return error;
    }

    static internal(message = 'Internal server error', isCritical = false) {
        return new AppError(message, 500, isCritical);
    }
}

module.exports = AppError; 