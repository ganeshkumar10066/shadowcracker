const jwt = require('jsonwebtoken');
const AppError = require('../utils/AppError');
const User = require('../models/User');

const protect = async (req, res, next) => {
    try {
        // 1) Get token from header
        let token;
        if (req.headers.authorization?.startsWith('Bearer')) {
            token = req.headers.authorization.split(' ')[1];
        }

        if (!token) {
            return next(AppError.unauthorized('Please log in to access this resource'));
        }

        // 2) Verify token
        const decoded = jwt.verify(token, process.env.JWT_SECRET);

        // 3) Check if user still exists
        const user = await User.findById(decoded.id);
        if (!user) {
            return next(AppError.unauthorized('User no longer exists'));
        }

        // 4) Check if user changed password after token was issued
        if (user.changedPasswordAfter(decoded.iat)) {
            return next(AppError.unauthorized('User recently changed password. Please log in again'));
        }

        // Grant access to protected route
        req.user = user;
        next();
    } catch (error) {
        next(AppError.unauthorized('Invalid token'));
    }
};

const restrictTo = (...roles) => {
    return (req, res, next) => {
        if (!roles.includes(req.user.role)) {
            return next(AppError.forbidden('You do not have permission to perform this action'));
        }
        next();
    };
};

module.exports = {
    protect,
    restrictTo
}; 